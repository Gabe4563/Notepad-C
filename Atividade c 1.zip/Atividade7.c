#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

double salario, imposto = 0.0;
int main(){
   

   
    scanf("%lf", &salario);

    if (salario <= 2000.00) {
        printf("\n Isento");
    } else if (salario <= 3000.00) {
        imposto = (salario - 2000.00) * 0.08;
        printf("\n R$ %.2f", imposto);
    } else if (salario <= 4500.00) {
        imposto = (1000.00 * 0.08) + (salario - 3000.00) * 0.18;
        printf("\n R$ %.2f", imposto);
    } else {
        imposto = (1000.00 * 0.08) + (1500.00 * 0.18) + (salario - 4500.00) * 0.28;
        printf("\n R$ %.2f", imposto);
    }

    return 0;
}