#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

double valor;
int main(){
   
    printf("\n Insira um valor: ");
    scanf("%lf", &valor);

    if (valor >= 0 && valor <= 25) {
        printf("\n Intervalo [0,25]");
    } else if (valor > 25 && valor <= 50) {
        printf("\n Intervalo (25,50]");
    } else if (valor > 50 && valor <= 75) {
        printf("\n Intervalo (50,75]");
    } else if (valor > 75 && valor <= 100) {
        printf("\n Intervalo (75,100]");
    } else {
        printf("\n Fora de intervalo");
    }

    return 0;
}