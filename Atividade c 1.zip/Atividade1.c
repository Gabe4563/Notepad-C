#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL, ""); // Identifica��o de todas as linguagens
	int num;

	printf("Digite um numero: ");
	scanf("%d", &num);

	if(num < 0){
		printf("\n Negativo");
}else{
	printf("\n Nao Negativo");
}
    printf("\nO numero �:%d", num);



    return 0;
}
