#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    int codigo, quantidade;
    float preço, total;
    scanf("%d %d", &codigo, &quantidade);

   
    if (codigo == 1) {
        preço = 4.00;
    } else if (codigo == 2) {
        preço = 4.50;
    } else if (codigo == 3) {
        preço = 500.00;  
    } else if (codigo == 4) {
        preço = 2.00;
    } else if (codigo == 5) {
        preço = 1.50;
    } else {
       
        printf("\n Código inválido!");
        return 1;  
    }

   
    total = preÇo * quantidade;

   
    printf("\n Valor a pagar: R$ %.2f", total);

    return 0;
}