#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int multiplo_1, multiplo_2;
int main(){
   

    printf("\n Insira o número: ");
    scanf("%d", &multiplo_1);

    printf("\n Insira o número: ");
    scanf("%d", &multiplo_2);

    if(multiplo_1 % multiplo_2 == 0 || multiplo_2 % multiplo_1 == 0){
        printf("\n São Multiplos");
    }else{
        printf("\n Não são Multiplos");
    }
	
    return 0;
}