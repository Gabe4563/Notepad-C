#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int num;
int main(){

	printf("Insira o numero:");
	scanf("%d", &num);

	if(num %2 == 0){
        printf("Par");
	}else{
	printf("Impar");
	}

}
