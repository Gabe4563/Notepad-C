#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int Horainicial, Horafinal, duracao;
int main() {

    printf("\n Insira a hora inicial: ");
    scanf("%d", &Horainicial);

    printf("\n Insira a hora final: ");
    scanf("%d", &Horafinal);

    if (Horafinal < Horainicial) {
        duracao = (24 - Horainicial) + Horafinal;
    } else {
        duracao = Horafinal - Horainicial;
    }

    printf("\n A duração é: %d horas", duracao);

    return 0;
}